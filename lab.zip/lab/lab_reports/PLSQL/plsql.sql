set serveroutput on;

DECLARE 
   a number(3) := 50; 
BEGIN 
   IF ( a = 10 ) THEN 
      dbms_output.put_line('Value of a is 10' ); 
   ELSIF ( a = 20 ) THEN 
      dbms_output.put_line('Value of a is 20' ); 
   ELSIF ( a = 30 ) THEN 
      dbms_output.put_line('Value of a is 30' ); 
   ELSE 
       dbms_output.put_line('None of the values is matching'); 
   END IF; 
   dbms_output.put_line('Exact value of a is: '|| a );  
END; 
/

------------------------------------------------------------------------------------------------

set serveroutput on;

DECLARE 
   i number(1); 
   j number(1); 
BEGIN 
   << outer_loop >> 
   FOR i IN 1..3 LOOP 
      << inner_loop >> 
      FOR j IN 1..3 LOOP 
         dbms_output.put_line('i is: '|| i || ' and j is: ' || j); 
      END loop inner_loop; 
   END loop outer_loop; 
END; 
/


-----------------------------------------------------------------------------------
---Creating a function
set serveroutput on;

CREATE OR REPLACE FUNCTION totalEmployee 
RETURN number IS 
   total number(2) := 0; 
BEGIN 
   SELECT count(*) into total 
   FROM employee; 
    
   RETURN total; 
END; 
/ 

---calling a function

DECLARE 
   c number(2); 
BEGIN 
   c := totalEmployee(); 
   dbms_output.put_line('Total no. of Employees: ' || c); 
END; 
/



---------------------------------------------------


---creating a trigger
CREATE OR REPLACE TRIGGER display_salary_changes 
BEFORE DELETE OR INSERT OR UPDATE ON employee 
FOR EACH ROW 
WHEN (NEW.ID > 0) 
DECLARE 
   sal_diff number; 
BEGIN 
   sal_diff := :NEW.sal  - :OLD.sal; 
   dbms_output.put_line('Old salary: ' || :OLD.sal); 
   dbms_output.put_line('New salary: ' || :NEW.sal); 
   dbms_output.put_line('Salary difference: ' || sal_diff); 
END; 
/ 

---triggering a trigger
Update employee
SET sal = sal+5000
WHERE id =3;

