
CREATE  OR REPLACE PROCEDURE  FetchTablesNames(c##lab IN VARCHAR) IS

CURSOR table_cursor IS
SELECT table_name
FROM all_tables
WHERE owner = c##lab;


v_table_name VARCHAR(30);

BEGIN
OPEN table_cursor;
FETCH table_cursor INTO v_table_name;
DBMA_OUTPUT.PUT_LINR('Table Name; '|| v_table_name);

END
CLOSE table_cursor;

SET SERVEROUTPUT ON;