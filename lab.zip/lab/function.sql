
create or replace function calcArea(v_l number,v_b number)
return number 
as

       v_result number(8,2);
       
begin

      v_result:=v_l*v_b;
      return v_result;
end;



set serveroutput on;
declare
      l number:=5;
      b number:=6;
      a number;
begin
     a:=calcArea(l,b);
     dbms_output.put_line('Area is ='||a);
end;     
