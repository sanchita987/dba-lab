


create or replace procedure out_para_proc(v_outParam out varchar2)
as

begin
     v_outParam := 'Luna';
end;


set serveroutput on

declare 
      v_out varchar2(30);
begin
      out_para_proc(v_out);
      dbms_output.put_line('Our out parameter is='||v_out);
end;      
      
