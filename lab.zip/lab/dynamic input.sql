set serveroutput on;

declare
     v_id int := 7;
     v_name varchar(30) := 'Luna';
     v_sal number(8,2) := 23000;
     v_dob date := '05-Apr-2000';
begin
     insert into employee (id,name,sal,dob) VALUES (v_id,v_name,v_sal,v_dob);
end; 

select *from employee;