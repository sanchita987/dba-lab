
create or replace function totalEmp
return int
as 
total int;
begin
select count(*) into total from employee;
return total;
end;


begin
       dbms_output.put_line('total no of emp='||totalEmp);
end;       
     