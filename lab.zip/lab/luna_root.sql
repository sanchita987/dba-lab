set serveroutput on

declare
        v_max_sal employee.sal%type;
        v_no_emp number(3);
        v_emp employee%rowtype;
        
begin
        select max(sal) into v_max_sal from employee;
        dbms_output.put_line('Max salary= '||v_max_sal);
        
        select count(*) into v_no_emp from employee where sal=v_max_sal;
        
        if v_no_emp>1 then
                  dbms_output.put_line('There are '||v_no_emp||' employee with max salary');
        else
            select * into v_emp from employee where sal=v_max_sal;
            dbms_output.put_line('The max salary employee is as below:');
            dbms_output.put_line('Name= '||v_emp.name);
            dbms_output.put_line('Date of Birth= '||v_emp.dob);
        
        end if;
        end;