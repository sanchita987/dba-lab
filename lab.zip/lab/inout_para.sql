create or replace procedure out_para_proc(v_outParam out varchar2)
as

begin
     dbms_output.put_line('Before return or concate='||v_outParam);
     v_outParam := v_outParam||'Parajuli';
end;


set serveroutput on

declare 
      v_out varchar2(30):='Luna';
begin
      out_para_proc(v_out);
      dbms_output.put_line('After return or concate='||v_out);
end;      
      
