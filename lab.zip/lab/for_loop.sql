
set serveroutput on

create or replace procedure emp_cur_proc (v_sal in employee.sal%type,v_no_emp out number(3))as

        cursor emp_cur is select*from employee where sal>=v sal;
        
begin
            select count(*)into v_no_emp from employee where sal>=v_sal;
            
            for v_emp in emp_cur loop
            
                dbms_output.put_line('Name='||v_emp.name||'salary='||v_emp.sal);
                
        end loop;

end;


declare 
    emp_cur_emp number(3);
begin
    emp_cur_proc(40000,v_no_emp);
    dbms_output.put_line('no of employee with salary greater than 40000'||v_n0_emp);
end;    
       









 create or replace procedure emp_cur_proc as
        cursor emp_cur is select*from employee;
        
begin
            for v_emp in emp_cur loop
            
                dbms_output.put_line('Name='||v_emp.name||'salary='||v_emp.sal);
                
        end loop;

end;
execute emp_cur_proc;





--for loop

begin
       for i in 1..5 loop
                     dbms_output.putline('Luna');
       end loop;  
end;      






