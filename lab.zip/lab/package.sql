
create or replace package emp_pkg as
            procedure find_emp(e_id employee.id%type);
end;         

            
create or replace package body emp_pkg as 
            procedure find_emp(e_id employee.id%type)
            is 
                  emp_record employee%rowtype;
            begin
                  select*into emp_record from employee where id=e_id;
                  dbms_output.put_line('Employee Name:'||emp_record.name);
                  dbms_output.put_line('Employee Salary:'||emp_record.sal);
            
            end find_emp;
end emp_pkg;

set serveroutput on;
Declare
begin
      emp_pkg.find_emp(4);
end;

set serveroutput on;
Declare
    id employee.id%type:=5;
begin
      emp_pkg.find_emp(id);
end;

---------------------------------------------------------------------------------------------------


create or replace package emp_pkg as
            procedure find_emp(e_id employee.id%type);
            function find_sal(e_id employee.id%type) return employee.sal%type;
            
end;   
/

            
create or replace package body emp_pkg as 
            procedure find_emp(e_id employee.id%type)
            is 
                  emp_record employee%rowtype;
            begin
                  select*into emp_record from employee where id=e_id;
                  dbms_output.put_line('Employee Name:'||emp_record.name);
                  dbms_output.put_line('Employee Salary:'||emp_record.sal);
            
            end find_emp;
            
            function find_sal(e_id employee.id%type)
            return employee.sal%type
            is
                emp_sal employee.sal%type;
        begin
            select sal into emp_sal from employee where id=e_id;
            return emp_sal;
            end find_sal;
                
                
                
end emp_pkg;
/


Declare
 id employee.id%type:=5;
 emp_sal employee.sal%type;
 
 begin
    emp_pkg.find(id);
    emp_sal:=emp_pkg.find_sal(id);
    dbms_output.put_line('Returned salary:='||emp_sal);
 end;   


---------------------------------------------------------------------------------------------

create or replace package emp_pkg as
            procedure find_emp(e_id employee.id%type);
            function find_sal(e_id employee.id%type) return employee.sal%type;
            procedure emp_list;
end;   
/

create or replace package body emp_pkg as 
            procedure find_emp(e_id employee.id%type)
            is 
                  emp_record employee%rowtype;
            begin
                  select*into emp_record from employee where id=e_id;
                  dbms_output.put_line('Employee Name:'||emp_record.name);
                  dbms_output.put_line('Employee Salary:'||emp_record.sal);
            
            end find_emp;

   function find_sal(e_id employee.id%type)
            return employee.sal%type
            is
                emp_sal employee.sal%type;
        begin
            select sal into emp_sal from employee where id=e_id;
            return emp_sal;
            end find_sal;
                
                procedure emp_list
                is
                    cursor emp_cur is select * from employee;
                begin
                    dbms_output.put_line ('List of employee');
                     dbms_output.put_line ('*************************');
                    
                    for emp_rec in emp_cur loop
                     dbms_output.put_line ('ID:'|| emp_rec.id||'Name:'||emp_rec.name);
                     
                     end loop;
                      dbms_output.put_line ('*************************');
                      end emp_list;
                
end emp_pkg;
/



Declare
 id employee.id%type:=5;
 emp_sal employee.sal%type;
 
 begin
    emp_pkg.find_emp(id);
    emp_sal:=emp_pkg.find_sal(id);
    dbms_output.put_line('Returned salary:='||emp_sal);
    
    emp_pkg.emp_list;
 end;   
 /




