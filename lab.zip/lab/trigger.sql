
set serveroutput on;
 
create or replace trigger display_sal_change
before update of sal
on employee

for each row

declare
       sal_diff employee.sal%type;
       

begin
       sal_diff:=:old.sal - :new.sal;
       dbms_output.put_line('Old salary=' ||:old.sal);
       dbms_output.put_line('New salary=' ||:new.sal);
       dbms_output.put_line('Salary difference=' ||sal_diff);
end;




