set serveroutput on

declare
        cursor emp_cur is select*from employee;
        v_emp emp_cur%rowtype;
       
begin
        open emp_cur;
        fetch emp_cur into v_emp;
        
        while emp_cur%found loop
                dbms_output.put_line('Name='||v_emp.name||'salary='||v_emp.sal);
                fetch emp_cur into v_emp;
        end loop;
        close emp_cur;


end;